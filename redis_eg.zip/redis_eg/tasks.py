import time

def long_running_task(x:int):
    time.sleep(10)
    return x * x