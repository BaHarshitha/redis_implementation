from fastapi import FastAPI, BackgroundTasks
from rq import Queue
from redis import Redis
from tasks import long_running_task

app = FastAPI()

redis_conn = Redis(host="localhost", port=6379)
queue = Queue("default", connection=redis_conn)


@app.post("/add-task/")
def add_task(background_tasks: BackgroundTasks, x: int):
    job = queue.enqueue(long_running_task, x)
    return {"job_id": job.get_id(), "status": "Task added to queue"}


@app.get("/job-status/{job_id}")
def get_status(job_id: str):
    job = queue.fetch_job(job_id)
    if job is None:
        return {"status": "Job not found"}
    return {"job_id": job_id, "status": job.get_status(), "data": job.result}
